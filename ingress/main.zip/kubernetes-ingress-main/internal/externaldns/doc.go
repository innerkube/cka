// Package externaldns implements External DNS controller for Virtual Server.
package externaldns
