# Deploy a Policy for access control

This is the example code used in the [Deploy a Policy for access control](https://docs.nginx.com/nginx-ingress-controller/configuration/access-control/) documentation.
