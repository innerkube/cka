# Installation

This folder includes Kubernetes manifests for installing NGINX or NGINX Plus Ingress Controller. Read the installation
instructions [here](https://docs.nginx.com/nginx-ingress-controller/installation/).
